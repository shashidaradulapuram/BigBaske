package com.bigbasket.app;

import org.openqa.selenium.By;

import com.bigbasket.framework.BaseClass;

public class BigBasket_Management extends BaseClass{
        
	    /////////////////////////////////////    ADD SITE || ADD FROM CATALOG || RECONFIGURE MODEL || DELETE MODEL /////////////////////////////////////////////////////////
	    public static By byClickLocationandPIN                = By.xpath("//a[@class='btn hvr-fade']");
		public static By byClickcitydropdown                  = By.xpath("(//div[contains(@class,'city-select')])[1]");
		public static By byClickcity                          = By.xpath("//input[@placeholder='Select your city']");
		public static By byClickarea                          = By.xpath("//input[@id='areaselect']");
		public static By bySelectarea                         = By.xpath("(//input[@qa='areaInput']//following::ul)[1]");
		public static By byContinueButton                     = By.xpath("//button[@name='continue']");
		public static By bySelectFromList                     = By.xpath("//a[@class='ui-select-choices-row-inner']");
		public static By bySelectOutList                      = By.xpath("//div[@class='skp-exp']");
		public static By byShopByCategory                     = By.xpath("//a[@qa='categoryDD']");
		public static By bySelectCategory                     = By.xpath("//a[@qa='categoryDD']/following::ul/li//ul/li[@data-submenu-id='bakery-cakes-dairy']");
		public static By bySelectCategoryBread                = By.xpath("//div[contains(@ng-if,'offer-by-category')]//span[text()='Breads & Buns']");
		
		public static By bySelectOneProductFromList           = By.xpath("(//div[@class='items']/div[@qa='product']//a[contains(@ng-href,'white-150-gm')]/following::div[contains(@class,'bskt-opt')]//button[@qa='add'])[1]");
		public static By bySelectTwoProductFromList           = By.xpath("(//div[@class='items']/div[@qa='product']//a[contains(@ng-href,'pav-240-g')]/following::div[contains(@class,'bskt-opt')]//button[@qa='add'])[1]");
		public static By bySelectMyBasket                     = By.xpath("//a[@qa='myBasket']");
		public static By byCheckOutBasket                     = By.xpath("//button[@qa='viewBasketMB']");
}