package com.bigbasket.app;

import java.io.File;

import org.aspectj.util.FileUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import org.testng.annotations.Test;

public class AddProductsToCart_Flow extends BigBasket_Management {
	@BeforeClass
	public void testSignIn() throws Exception 
	   {
		try {
			    openBrowser();
		    	signIntoRibbon();		    	
		    } catch (Exception e) 
		    {
			log.error("Login/SignIn un-successful");
			e.printStackTrace();
			throw e;
		    }
	   }
	@Test (priority = -1, description = "Select Location and PIN Code")
	public void testAddLocationandPIN() throws Exception {
		
			try {
				    click(byClickLocationandPIN);
				    hardWait(5);
				    click(byClickcitydropdown);
				    enterText(byClickcity,byEnteryourcity); 
				    click(bySelectFromList);
					System.out.println("Selected Location and PIN Code");					
					enterText(byClickarea,byEnteryourarea);
					hardWait(5);
					click(bySelectarea);
					hardWait(5);
					click(byContinueButton);					
				}         
	    	    catch (Exception e) {
				File screenShot=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		    	Reporter.log("Login unsuccessful - Screenshot");
		    	FileUtil.copyFile(screenShot, new File("E:\\Selenium\\Workspace\\Ribbon\\Workspace\\BigBasket\\resources\\reportng\\scr1.png"));
		    	Reporter.log("<a href="+"E:\\Selenium\\Workspace\\Ribbon\\Workspace\\BigBasket\\resources\\reportng\\scr1.png"+">screenshot</a>");
		    	log.error("Salesforce login and navigate to CPQ unsuccessful");
		    	e.printStackTrace();
				throw e;
		    }
	    }            
         
	@Test (priority = 0, description = "Shop By Category")
	public void testShopByCategory() throws Exception {
		try { 	                     
            click(byShopByCategory);
			click(bySelectCategory);
			click(bySelectCategoryBread);    			
		    } catch (Exception e) {
			File screenShot=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	    	Reporter.log("Shop By Category unsuccessful - Screenshot");
	    	FileUtil.copyFile(screenShot, new File("E:\\Selenium\\Workspace\\Ribbon\\Workspace\\BigBasket\\resources\\reportng\\scr2.png"));
	    	Reporter.log("<a href="+"E:\\Selenium\\Workspace\\Ribbon\\Workspace\\BigBasket\\resources\\reportng\\scr2.png"+">screenshot</a>");
	    	log.error("Shop By Category  unsuccessful");
	    	e.printStackTrace();
			throw e;
		    }
	}
	
	@Test (priority = 1, description = "Add To Basket")
	public void testAddToMyBasket() throws Exception {
		try { 
			hardWait(5);
			Select breads=new Select(driver.findElement(By.id("sel1")));
			breads.selectByVisibleText("Price - Low to High");
			click(bySelectOneProductFromList);
			click(bySelectTwoProductFromList);
			
		    } catch (Exception e) {
			File screenShot=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	    	Reporter.log("Add To Basket unsuccessful - Screenshot");
	    	FileUtil.copyFile(screenShot, new File("E:\\Selenium\\Workspace\\Ribbon\\Workspace\\BigBasket\\resources\\reportng\\scr3.png"));
	    	Reporter.log("<a href="+"E:\\Selenium\\Workspace\\Ribbon\\Workspace\\BigBasket\\resources\\reportng\\scr3.png"+">screenshot</a>");
	    	log.error("Add To Basket unsuccessful");
	    	e.printStackTrace();
			throw e;
		}
	}
	
	@Test (priority = 2, description = "Screenshot of MyBasket")
	public void testAddScreenshotOfMyBasket() throws Exception {
		try { 
			hardWait(5);			
			click(bySelectMyBasket);
			hardWait(5);
			File screenShot=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	    	Reporter.log("MyBasket - Screenshot");
	    	FileUtil.copyFile(screenShot, new File("E:\\Selenium\\Workspace\\Ribbon\\Workspace\\BigBasket\\resources\\reportng\\scr4.png"));
	    	Reporter.log("<a href="+"E:\\Selenium\\Workspace\\Ribbon\\Workspace\\BigBasket\\resources\\reportng\\scr4.png"+">screenshot</a>");
			click(byCheckOutBasket);         
			
		    } catch (Exception e) {
			File screenShot=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	    	Reporter.log("MyBasket unsuccessful - Screenshot");
	    	FileUtil.copyFile(screenShot, new File("E:\\Selenium\\Workspace\\Ribbon\\Workspace\\BigBasket\\resources\\reportng\\scr5.png"));
	    	Reporter.log("<a href="+"E:\\Selenium\\Workspace\\Ribbon\\Workspace\\BigBasket\\resources\\reportng\\scr5.png"+">screenshot</a>");
	    	log.error("Add To Basket unsuccessful");
	    	e.printStackTrace();
			throw e;
		}
	}
	@AfterClass
	public void testSignout() throws Exception {
		try {
			closeCurrentBrowser();			
			} catch (Exception e) {
			log.error("Logout/SignOut un-successful");
			e.printStackTrace();
			throw e;
		}
	}
}
