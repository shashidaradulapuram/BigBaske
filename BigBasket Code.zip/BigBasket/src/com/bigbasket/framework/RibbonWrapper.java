package com.bigbasket.framework;

import java.io.File;

import org.aspectj.util.FileUtil;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.Reporter;


public class RibbonWrapper extends SeleniumWrapper{
	
	public static void signIntoRibbon() throws Exception{
		signIntoRibbon(baseUrl);
	}
	
   	public static void signIntoRibbon(String baseurl) throws Exception {
		try {
				enterURL(baseurl);				
				//enterText(byUserIDTextFieldID, byusername);
				//enterText(byPasswordTextFieldID, bypassword);
				//click(bySignInButtonID);
				
			} catch (Exception e) {
				
				File screenShot=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		    	Reporter.log(" Signin process un-successfull - Screenshot");
		    	FileUtil.copyFile(screenShot, new File("E:\\Selenium\\Workspace\\Ribbon\\Workspace\\BigBasket\\resources\\reportng\\scr.png"));
		    	Reporter.log("<a href="+"E:\\Selenium\\Workspace\\Ribbon\\Workspace\\BigBasket\\resources\\reportng\\scr.png"+">screenshot</a>");
		    	log.error("Error in the signin process");
		    	e.printStackTrace();
				throw e;
				
			}
	}
   
}
