package com.bigbasket.framework;

import java.io.FileReader;
import java.io.Reader;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

public class YamlWrapper {
	
	public final static String TEST_EXECUTION_CONFIG_FILE_PATH = "./resources/config/test_execution/bb.yaml";		
	
	public static Map<?,?> yamlMaps = readTestExecutionConfigurationFile() ; 

	public static String getBrowserName() {
		return (String) yamlMaps.get("browser");
	}	
	
	public static String getBaseUrl() {
		return (String) yamlMaps.get("url");
	}
	
	public static String getEnterCity() {
		return (String) yamlMaps.get("city");
	}
	public static String getEnterArea() {
		return (String) yamlMaps.get("area");
	}
	public static String getUsername() {
		return (String) yamlMaps.get("username");
	}
	public static String getPassword() {
		return (String) yamlMaps.get("password");
	}	
	
	public static Integer getWebDriverWaitTime() {
		return (Integer) yamlMaps.get("webdriverWaitTime");
	}
	public static String getValueFromYAMLAsString(String key) {
		return (String) yamlMaps.get(key);
	}
	
	public static Integer getValueFromYAMLAsInteger(String key) {
		return (Integer) yamlMaps.get(key);
	}
	
	public static Object getValueFromYAMLAsObject(String key) {
		return yamlMaps.get(key);
	}
	
	private static Map<?, ?> readTestExecutionConfigurationFile() {
		try {
			Yaml yaml = new Yaml();
			Reader yamlFile = new FileReader(TEST_EXECUTION_CONFIG_FILE_PATH);
			return (Map<?,?>) yaml.load(yamlFile);
		} catch (Exception e) {
			GlobalVariables.log.error(e);
			return null;
		}
	}

}
