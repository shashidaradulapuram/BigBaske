package com.bigbasket.framework;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.google.common.io.Files;

//com.bigbasket.framework - Contains the Base Framework around which the BBTesting project is build.
//Hierarchy of Classes in the com.bigbasket.framework is as follows(Class to the right inherits/extends the class to the left):
//GlobalVariable >> GlobalObjectRepository >> ReUsableMethods >> SeleniumWrapper >> LoudSightWrapper >> BaseClass

public class GlobalVariables {

	public final static Logger log = initLogger();
	
	public static Actions               actions; 
	public static Alert                 alert;
	public static By                    by; 
	//public static Wait                  implicit;
	public static String 			    currUserDirectory = System.getProperty("user.dir");
	public static WebDriver             driver;
	public static JavascriptExecutor    jse;
	public static SoftAssert 		    softAssert = new SoftAssert();
	public static WebDriverWait         wait; 
	public static WebElement            webElement;
	
	
	public final static String LOG4J2_CONFIG_FILE_PATH 	       = "./resources/config/logger/log4j2.xml";
	public final static String WEBDRIVER_EXECUTABLES_PATH 	   = "./resources/drivers/";
	
	public final static String BROWSER 					= YamlWrapper.getBrowserName();
	
	public final static Integer WEBDRIVER_WAIT_TIME 	= YamlWrapper.getWebDriverWaitTime();


	//Storing the WebTable in HashMap
	public static HashMap<Integer, HashMap <Integer, String>>     webTableData    = new HashMap<Integer, HashMap <Integer, String>>();
	public static HashMap<Integer, HashMap <Integer, WebElement>> webTableElement = new HashMap<Integer, HashMap <Integer, WebElement>>();
    
	
	//URL's 
	public static String baseUrl 	= YamlWrapper.getBaseUrl();
	
	
	
	//Login Credentials
	public static String byusername     				= YamlWrapper.getUsername();
	public static String bypassword     				= YamlWrapper.getPassword();
	
	public static String byEnteryourcity     			= YamlWrapper.getEnterCity();
	public static String byEnteryourarea     			= YamlWrapper.getEnterArea();
	
	public static Logger initLogger() {
		System.setProperty("log4j.configurationFile",LOG4J2_CONFIG_FILE_PATH);
		return LogManager.getLogger(GlobalVariables.class.getName());
	}
	
	public static void renameAndMovePreviousTestNGReport() {
		try {
			String timeStamp     = new SimpleDateFormat("HH-mm a - dd MMM YYYY").format(new Date());
			File sourceFile 	 = new File("./test-output/emailable-report.html");
			File destinationFile = new File("./resources/reports/" + timeStamp + "_emailable-report.html" );
			Files.copy(sourceFile , destinationFile );
			
		} catch (IOException e) {
			log.error(e);
		}
	}
	
}