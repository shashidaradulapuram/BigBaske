package com.bigbasket.framework;

public enum Browsers {
	
	CHROME , EDGE , FIREFOX , IE , CHROME_HEADLESS , FIREFOX_HEADLESS , HTML_UNIT_DRIVER , PHANTOM_JS ;
}
